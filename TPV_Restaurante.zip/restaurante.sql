-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-04-2021 a las 12:48:28
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `restaurante`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `IDCliente` int(11) NOT NULL,
  `DNI` varchar(11) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Apellidos` varchar(255) NOT NULL,
  `Direccion` varchar(255) NOT NULL,
  `Telefono` varchar(11) NOT NULL,
  `Habitual` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`IDCliente`, `DNI`, `Nombre`, `Apellidos`, `Direccion`, `Telefono`, `Habitual`) VALUES
(1, '57992247', 'Juan', 'Rodriguez Mata', 'Balmes', '60947869', 'SI'),
(2, '57992248', 'Francisca', 'Perez Perez', 'Callao', '60947868', 'No'),
(3, '57889076', 'Monica', 'Gutierrez', 'Ramirez', '55468875', 'Si'),
(4, '5678908', 'Mario', 'Gonzalez', 'Prieto', '69486733', 'No');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_ventas`
--

CREATE TABLE `detalle_ventas` (
  `IDDetalleVentas` int(11) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `PrecioVenta` double NOT NULL,
  `IdVentas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `detalle_ventas`
--

INSERT INTO `detalle_ventas` (`IDDetalleVentas`, `Nombre`, `Cantidad`, `PrecioVenta`, `IdVentas`) VALUES
(25, 'Hamburguesa', 1, 7, 24),
(26, 'Hamburguesa', 1, 7, 24),
(27, 'Hamburguesa', 1, 7, 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `IDProducto` int(11) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Stock` int(100) NOT NULL,
  `Categoria` varchar(255) NOT NULL,
  `Precio` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`IDProducto`, `Nombre`, `Stock`, `Categoria`, `Precio`) VALUES
(1, 'Hamburguesa', 42, 'Comidas', 7),
(2, 'Cafe Solo', 30, 'Cafes', 1),
(3, 'Cafe con leche', 50, 'Cafes', 1.5),
(5, 'Patatas Fritas', 50, 'Tapas', 3.5),
(6, 'Lubina', 10, 'Pescados', 15),
(7, 'Rodaballo', 10, 'Pescados', 17),
(8, 'Besugo', 15, 'Pescados', 21),
(9, 'Filete Ternera', 20, 'Comidas', 14),
(11, 'Croquetas', 20, 'Tapas', 8),
(12, 'Coca Cola', 50, 'Bebidas', 2.4),
(13, 'Fanta', 50, 'Bebidas', 2.4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedor`
--

CREATE TABLE `vendedor` (
  `IDVendedor` int(11) NOT NULL,
  `DNI` varchar(10) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Apellidos` varchar(255) NOT NULL,
  `Telefono` varchar(15) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `vendedor`
--

INSERT INTO `vendedor` (`IDVendedor`, `DNI`, `Nombre`, `Apellidos`, `Telefono`, `Password`) VALUES
(1, '11111112U', 'Maria', 'Perez Rodriguez', '68967036', '12345'),
(2, '56337899T', 'Laia', 'Higon Valero', '65544788', '12345');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `IDVentas` int(11) NOT NULL,
  `Cliente` varchar(255) NOT NULL,
  `Vendedor` varchar(255) NOT NULL,
  `SumaFinal` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`IDVentas`, `Cliente`, `Vendedor`, `SumaFinal`) VALUES
(12, 'Juan', 'TPV Restaurante', 28),
(13, 'Juan', 'TPV Restaurante', 4),
(14, 'Juan', 'TPV Restaurante', 4),
(15, 'Juan', 'TPV Restaurante', 35),
(16, 'Francisca', 'TPV Restaurante', 28),
(17, 'Francisca', 'TPV Restaurante', 7),
(18, 'Juan', 'TPV Restaurante', 14),
(19, 'Mario', 'TPV Restaurante', 14),
(20, 'Mario', 'TPV Restaurante', 14),
(21, 'Mario', 'TPV Restaurante', 21),
(22, 'Mario', 'TPV Restaurante', 14),
(23, 'Mario', 'TPV Restaurante', 21),
(24, 'Mario', 'TPV Restaurante', 14),
(25, 'Mario', 'TPV Restaurante', 7);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`IDCliente`);

--
-- Indices de la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  ADD PRIMARY KEY (`IDDetalleVentas`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`IDProducto`);

--
-- Indices de la tabla `vendedor`
--
ALTER TABLE `vendedor`
  ADD PRIMARY KEY (`IDVendedor`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`IDVentas`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `IDCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  MODIFY `IDDetalleVentas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `IDProducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `vendedor`
--
ALTER TABLE `vendedor`
  MODIFY `IDVendedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `IDVentas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
