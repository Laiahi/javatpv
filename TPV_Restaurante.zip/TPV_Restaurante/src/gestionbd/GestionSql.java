package gestionbd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class GestionSql {

    /**
     * Método para declarar el driver, el servidor, la base de datos, el usuario
     * y la contraseña.
     *
     */
    private static Connection conn;
    Statement st;
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    public static final String URL = "jdbc:mysql://localhost:3306/restaurante";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    public Statement statement;
    public ResultSet resulset;

    /**
     * Método para establecer la conexión.
     *
     * @return devuelve la conexión.
     */
    public static Connection openConnection() {

        //Declaramos static el try-catch porque sino da error por si falla el driver
        conn = null;
        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            if (conn != null) {
                System.out.println("Conexión establecida");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar" + e);
        }
        return conn;
    }

    /**
     * Método para desconectar la conexión.
     *
     */
    public void closeConnection() {
        conn = null;
        if (conn == null) {
            System.out.println("Conexión terminada");
        }
    }

    /**
     * Método para ejecutar comandos SQL.
     *
     */
    public void executeSql(String sql) {
        try {

            statement = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            resulset = statement.executeQuery(sql);

        } catch (SQLException sqlex) {
            JOptionPane.showMessageDialog(null, "No ha sido posible " + "ejecutar comando sql ," + sqlex + "o el último sql es " + sql);

        }
    }
}
