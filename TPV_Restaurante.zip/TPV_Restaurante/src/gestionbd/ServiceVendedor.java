
package gestionbd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ServiceVendedor {
     /**
     * Código para realizar la conexión.
     *
     */
    
    public static GestionSql conexion = new GestionSql();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Login vend = new Login ();
    
     /**
     * Este método sirve para guardar los campos de la tabla vendedor.
     *
     * @param Login. llama al login.
     * 
     * @return true si los campos son correctos y false si no coinciden.
     *
     */
    
   public boolean saveVendedor(Login vend) {

        String sql = ("INSERT INTO vendedor (IDVendedor, DNI, Nombre, Apellidos, Telefono, Password) VALUES (?, ?, ?, ?, ?, ?)");

        try {

            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, vend.getIDVendedor());
            ps.setString(2, vend.getDni());
            ps.setString(3, vend.getNombre());
            ps.setString(4, vend.getApellidos());
            ps.setString(5, vend.getTelefono());
            ps.setString(6, vend.getPassword());
            
            ps.execute();
            con.close();
            return true;

        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }
 
  /**
     * Método para cargar los datos del vendedor.
     *
     * @return devuelve la lista de vendedores.
     *
     */
    public List getVendedor() {

        List<Login> Listavend = new ArrayList();

        String sql = "SELECT * FROM vendedor";

        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
               Login vend = new Login ();
                vend.setIDVendedor(rs.getInt("IDVendedor"));
                vend.setDni(rs.getString("dni"));
                vend.setNombre(rs.getString("nombre"));
                vend.setApellidos(rs.getString("apellidos"));
                vend.setTelefono(rs.getString("telefono"));
                vend.setPassword(rs.getString("password"));
                Listavend.add(vend);
            }
        } catch (Exception e) {

        }
        return Listavend;
    }

    /**
     * Este método sirve para eliminar el vendedor.
     *
     * @param IDVendedor. llama al IdVendedor.
     * 
     * @return true si los datos son correctos, false si hay algún error.
     *
     */
    public boolean deleteVendedor(int IDVendedor) {

        String sql = "DELETE FROM vendedor WHERE IDVendedor=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, IDVendedor);
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }
     /**
     * Este método sirve para actualizar los datos del vendedor.
     *
     * @param Login. Llama al login.
     * 
     * @return true si los datos son correctos, false si hay algún error.
     *
     */

    public boolean updateVendedor(Login vend) {
        String sql = "UPDATE vendedor SET Dni=?, Nombre=?,Apellidos=?, Telefono=?, Password=? WHERE IDVendedor=?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, vend.getDni());
            ps.setString(2, vend.getNombre());
            ps.setString(3, vend.getApellidos());
            ps.setString(4, vend.getTelefono());
            ps.setString(5, vend.getPassword());
            ps.setInt(6, vend.getIDVendedor());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }
   
}
