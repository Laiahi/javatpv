
package gestionbd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDAO {
    
     /**
     * Código para establecer la conexión.
     */
    
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    GestionSql cn = new GestionSql();
    
     /**
     * Este método sirve para seleccionar los campos nombre y contraseña de la tabla vendedor.
     * 
     * @param nombre. Llama al nombre.
     * @param password. Llama al password.
     * 
     * @return para que no nos de error el método.
     *
     */
    
    public Login log (String nombre, String password){
        Login l = new Login();
        String sql = "SELECT * FROM vendedor WHERE nombre =? AND password = ? ";
        try{
           con =  cn.openConnection();
           ps =con.prepareStatement(sql);
           ps.setString (1,nombre);
           ps.setString(2, password);
           rs = ps.executeQuery();
           if (rs.next()){
             
               l.setDni(rs.getString("dni"));
               l.setNombre(rs.getString("nombre")); 
               l.setApellidos (rs.getString ("apellidos"));
               l.setTelefono(rs.getString("telefono"));           
               l.setPassword(rs.getString("password"));        
           }
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return l;
    }
    
}
