package gestionbd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceCliente {

    /**
     * Código para establecer la conexión.
     *
     */
    public static GestionSql conexion = new GestionSql();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cliente cl = new Cliente();

    /**
     * Este método sirve para guardar los datos de un nuevo cliente.
     *
     * @param cl. Llama al cliente.
     *
     * @return true si los datos son correctos, false si hay algún error.
     *
     */
    public boolean saveCliente(Cliente cl) {

        String sql = ("INSERT INTO cliente (IDCliente, DNI, Nombre, Apellidos, Direccion, Telefono, Habitual) VALUES (?, ?, ?, ?, ?, ?, ?)");

        try {

            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, cl.getIDCliente());
            ps.setString(2, cl.getDni());
            ps.setString(3, cl.getNombre());
            ps.setString(4, cl.getApellidos());
            ps.setString(5, cl.getDireccion());
            ps.setString(6, cl.getTelefono());
            ps.setString(7, cl.getHabitual());
            ps.execute();
            con.close();
            return true;

        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }

    /**
     * Este método sirve para cargar los datos del cliente.
     *
     * @return devuelve los datos de la lista clientes.
     *
     */
    public List getCliente() {

        List<Cliente> ListaCl = new ArrayList();

        String sql = "SELECT * FROM cliente";

        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cliente cl = new Cliente();
                cl.setIDCliente(rs.getInt("IDCliente"));
                cl.setDni(rs.getString("dni"));
                cl.setNombre(rs.getString("nombre"));
                cl.setApellidos(rs.getString("apellidos"));
                cl.setDireccion(rs.getString("direccion"));
                cl.setTelefono(rs.getString("telefono"));
                cl.setHabitual(rs.getString("habitual"));
                ListaCl.add(cl);
            }
        } catch (Exception e) {

        }
        return ListaCl;
    }

    /**
     * Este método sirve para eliminar datos del cliente.
     *
     * @param IDCliente. Busca el IDCliente.
     *
     * @return true si los datos son correctos, false si hay algún error.
     *
     */
    public boolean deleteCliente(int IDCliente) {

        String sql = "DELETE FROM cliente WHERE IDCliente=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, IDCliente);
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }

    /**
     * Este método sirve para actualizar los datos del cliente.
     *
     * @param cl. llama al cliente.
     *
     * @return true si los datos son correctos, false si hay algúna excepción.
     *
     */

    public boolean updateCliente(Cliente cl) {
        String sql = "UPDATE cliente SET DNI=?,Nombre=?, Apellidos=?,Direccion=?, Telefono=? , Habitual =? WHERE IDCliente=?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, cl.getDni());
            ps.setString(2, cl.getNombre());
            ps.setString(3, cl.getApellidos());
            ps.setString(4, cl.getDireccion());
            ps.setString(5, cl.getTelefono());
            ps.setString(6, cl.getHabitual());
            ps.setInt(7, cl.getIDCliente());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }

    /**
     * Método para buscar al cliente.
     *
     * @param DNI. Llama a el DNI del cliente.
     *
     * @return ddevuelve el cliente.
     *
     */
    public Cliente BuscarCliente(String DNI) {
        Cliente cl = new Cliente();
        String sql = "SELECT * FROM cliente WHERE DNI=?";
        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, DNI);
            rs = ps.executeQuery();
            if (rs.next()) {
                cl.setNombre(rs.getString("nombre"));
                cl.setApellidos(rs.getString("apellidos"));
                cl.setDireccion(rs.getString("direccion"));
                cl.setTelefono(rs.getString("telefono"));
                cl.setHabitual(rs.getString("habitual"));
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return cl;
    }
}
