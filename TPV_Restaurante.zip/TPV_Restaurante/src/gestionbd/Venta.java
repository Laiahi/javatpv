package gestionbd;

public class Venta {

    int IDVentas;
    String Cliente;
    String Vendedor;
    Double SumaFinal;

    /**
     * Constructor vacío de la clase Venta.
     *
     */
    public Venta() {
    }

    /**
     * Constructor de la clase Venta.
     *
     */
    public Venta(int IDVentas, String Cliente, String Vendedor, Double SumaFinal) {
        this.IDVentas = IDVentas;
        this.Cliente = Cliente;
        this.Vendedor = Vendedor;
        this.SumaFinal = SumaFinal;
    }

    /**
     * Métodos get y setter.
     *
     */
    public int getIDVentas() {
        return IDVentas;
    }

    public void setIDVentas(int IDVentas) {
        this.IDVentas = IDVentas;
    }

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String IdCliente) {
        this.Cliente = IdCliente;
    }

    public String getVendedor() {
        return Vendedor;
    }

    public void setVendedor(String IdVendedor) {
        this.Vendedor = IdVendedor;
    }

    public Double getSumaFinal() {
        return SumaFinal;
    }

    public void setSumaFinal(Double SumaFinal) {
        this.SumaFinal = SumaFinal;
    }

}
