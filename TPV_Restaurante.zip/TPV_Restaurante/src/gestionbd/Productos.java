package gestionbd;

public class Productos {

    private int IDProducto;
    private String nombre;
    private String precio;
    private int stock;
    private String categoria;
    int cantidad = 1;

    /**
     * Constructor vacío.
     *
     */

    public Productos() {
    }

    /**
     * Constructor de la clase Productos.
     *
     */
    public Productos(int IDProducto, String nombre, String precio, int stock, String categoria, int cantidad) {
        this.IDProducto = IDProducto;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        this.categoria = categoria;
        this.cantidad = cantidad;
    }

    /**
     * Métodos get y setter de la clase Producto.
     *
     */
    public int getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(int IDProducto) {
        this.IDProducto = IDProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

}
