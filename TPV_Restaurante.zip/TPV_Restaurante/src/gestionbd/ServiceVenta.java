package gestionbd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceVenta {

    /**
     * Código para realizar la conexión a la base de datos.
     *
     */
    public static GestionSql conexion = new GestionSql();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r;

    /**
     * Método para seleccionar el Id de la tabla ventas de nuestra base de
     * datos.
     *
     * @return devuelve el Id.
     *
     */
    public int IdVenta() {
        int id = 0;
        String sql = "SELECT MAX(IDVentas) FROM ventas";

        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
        return id;
    }

    /**
     * Este método sirve para guardar los campos de la tabla ventas.
     *
     * @param Venta. Busca la venta.
     * 
     * @return devuelve la venta.
     *
     */
    public int saveVenta(Venta v) {

        String sql = ("INSERT INTO ventas (IDVentas, Cliente, Vendedor, SumaFinal) VALUES (?, ?, ?, ?)");

        try {

            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, v.getIDVentas());
            ps.setString(2, v.getCliente());
            ps.setString(3, v.getVendedor());
            ps.setDouble(4, v.getSumaFinal());
            ps.execute();

        } catch (Exception e) {
            System.out.println(e.toString());

        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
        return r;
    }

    /**
     * Este método sirve para guardar los datos de la venta en la tabla detalle
     * ventas.
     *
     * @param Detalle. Llama al detalle.
     * 
     * @return devuelve el detalle de la venta.
     *
     */
    public int saveDetalle(Detalle dv) {
        String sql = "INSERT INTO detalle_ventas (Nombre, Cantidad, PrecioVenta, IdVentas) VALUES (?, ?, ?, ?)";
        try {

            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, dv.getNombre());
            ps.setInt(2, dv.getCantidad());
            ps.setDouble(3, dv.getPrecioVenta());
            ps.setInt(4, dv.getIdVentas());
            ps.execute();

        } catch (SQLException ex) {
            System.out.println(ex.toString());

        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
        return r;
    }

    /**
     * Método para actualizar el stock de la tabla producto.
     *
     * @param cant. Establece la cantidad.
     * 
     * @param nom.Establece el nombre.
     * 
     * @return true si los parametros son correctos, false si no coinciden.
     *
     */
    public boolean actualizarStock(int cant, String nom) {

        String sql = "UPDATE producto SET Stock =? WHERE Nombre = ?";
        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, cant);
            ps.setString(2, nom);
            ps.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return false;
        }
    }

    /**
     * Método para llamar a la venta.
     *
     * @return devuelve la lista con las ventas.
     *
     */

    public List getVenta() {

        List<Venta> Listavent = new ArrayList();

        String sql = "SELECT * FROM ventas";

        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Venta vent = new Venta();
                vent.setIDVentas(rs.getInt("IDVentas"));
                vent.setCliente(rs.getString("Cliente"));
                vent.setVendedor(rs.getString("Vendedor"));
                vent.setSumaFinal(rs.getDouble("SumaFinal"));
                Listavent.add(vent);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return Listavent;
    }
}
