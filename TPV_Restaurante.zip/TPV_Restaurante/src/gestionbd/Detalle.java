package gestionbd;

public class Detalle {

    private int IDDetalleVentas;
    private String Nombre;
    private int IdVentas;
    private int cantidad;
    private double PrecioVenta;

    /**
     * Constructor vacío de la clase Detalle.
     *
     */
    public Detalle() {
    }

    /**
     * Constructor de la clase Detalle.
     *
     */
    public Detalle(int IDDetalleVentas, String Nombre, int IdVentas, int cantidad, double PrecioVenta) {
        this.IDDetalleVentas = IDDetalleVentas;
        this.Nombre = Nombre;
        this.IdVentas = IdVentas;
        this.cantidad = cantidad;
        this.PrecioVenta = PrecioVenta;
    }

    /**
     * Métodos get y setter de la clase Detalle.
     *
     */
    public int getIDDetalleVentas() {
        return IDDetalleVentas;
    }

    public void setIDDetalleVentas(int IDDetalleVentas) {
        this.IDDetalleVentas = IDDetalleVentas;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getIdVentas() {
        return IdVentas;
    }

    public void setIdVentas(int IdVentas) {
        this.IdVentas = IdVentas;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioVenta() {
        return PrecioVenta;
    }

    public void setPrecioVenta(double PrecioVenta) {
        this.PrecioVenta = PrecioVenta;
    }

}
