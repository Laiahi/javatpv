package gestionbd;

public class Cliente {

    int IDCliente;
    String dni;
    String nombre;
    String apellidos;
    String direccion;
    String telefono;
    String habitual;

    /**
     * Métodos get y setter de la clase Cliente.
     *
     */
    public int getIDCliente() {
        return IDCliente;
    }

    public void setIDCliente(int idCliente) {
        this.IDCliente = idCliente;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getHabitual() {
        return habitual;
    }

    public void setHabitual(String habitual) {
        this.habitual = habitual;
    }
}
