package gestionbd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceProductos {

    /**
     * Código para realizar la conexión.
     *
     */
    public static GestionSql conexion = new GestionSql();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Productos pro = new Productos();

    /**
     * Método para guardar productos de la tabla producto.
     *
     * @param pro. Llama al producto.
     *
     * @return true si los datos son correctos, false si hay algún error.
     *
     */
    public boolean saveProducto(Productos pro) {

        String sql = ("INSERT INTO producto (IDProducto, Nombre, Stock, Categoria, Precio) VALUES (?, ?, ?, ?, ?)");

        try {

            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, pro.getIDProducto());
            ps.setString(2, pro.getNombre());
            ps.setInt(3, pro.getStock());
            ps.setString(4, pro.getCategoria());
            ps.setString(5, pro.getPrecio());

            ps.execute();
            con.close();
            return true;

        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }

    /**
     * Este método sirve para cargar la tabla de productos.
     *
     * @return devuelve la lista de productos.
     *
     */
    public List getProducto() {

        List<Productos> Listapro = new ArrayList();

        String sql = "SELECT * FROM producto";

        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listapro.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return Listapro;
    }

    /**
     * Este método sirve para eliminar un producto de la tabla producto.
     *
     * @param IDProducto. Busca el producto por el Id.
     *
     * @return devuelve true si los datos son correctos, false si hay algún
     * error.
     *
     */
    public boolean deleteProducto(int IDProducto) {

        String sql = "DELETE FROM producto WHERE IDProducto=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, IDProducto);
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }

    /**
     * Método para actualizar los datos de la tabla producto.
     *
     * @param pro. busca el producto.
     *
     * @return devuelve true si los datos son correctos, false si hay algun
     * error.
     *
     */
    public boolean updateProducto(Productos pro) {
        String sql = "UPDATE producto SET Nombre=?,Stock=?, Categoria=?, Precio=? WHERE IDProducto=?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getNombre());
            ps.setInt(2, pro.getStock());
            ps.setString(3, pro.getCategoria());
            ps.setString(4, pro.getPrecio());
            ps.setInt(5, pro.getIDProducto());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }

}
