package gestionbd;

public class Login {

    int IDVendedor;
    String dni;
    String nombre;
    String apellidos;
    String telefono;
    String password;

    /**
     * Constructor vacío de la clase Login.
     *
     */
    public Login() {

    }

    /**
     * Constructor de la clase Login.
     *
     */
    public Login(int IDVendedor, String dni, String nombre, String apellidos, String telefono, String password) {
        this.IDVendedor = IDVendedor;
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.password = password;
    }

    /**
     * Métodos get y setter de la clase Login.
     *
     */
    public int getIDVendedor() {
        return IDVendedor;
    }

    public void setIDVendedor(int IDVendedor) {
        this.IDVendedor = IDVendedor;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
