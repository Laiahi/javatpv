package base.de.datos;

import gestionbd.GestionSql;
import gestionbd.Productos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ServicioClientes {

    public static GestionSql conexion = new GestionSql();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Productos pro = new Productos();
    int r;

    /**
     * Este método sirve para buscar el nombre del producto.
     *
     * @param nom. Busca el producto por nombre.
     * @return devuelve el producto.
     *
     */
    public Productos BuscarPro(String nom) {
        Productos producto = new Productos();
        String sql = "SELECT * FROM producto WHERE Nombre=?";
        try {
            con = conexion.openConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, nom);
            rs = ps.executeQuery();
            if (rs.next()) {
                producto.setNombre(rs.getString("nombre"));
                producto.setStock(rs.getInt("stock"));
                producto.setCategoria(rs.getString("categoria"));
                producto.setPrecio(rs.getString("precio"));

            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return producto;
    }
   /**
     * Método para buscar en la lista productos el Filete de ternera.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarFilete() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Filete Ternera'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos la Hamburguesa.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarHamburguesa() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Hamburguesa'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos el Café Solo.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarCafeSolo() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Cafe Solo'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos el Café con leche.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarCafeLeche() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Cafe con Leche'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos las Patatas Fritas.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarPatatasFritas() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Patatas Fritas'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos las Croquetas.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarCroquetas() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Croquetas'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos la Lubina.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarLubina() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Lubina'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos el Rodaballo.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarRodaballo() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Rodaballo'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos el Besugo.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarBesugo() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Besugo'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos la Fanta.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarFanta() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Fanta'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
   /**
     * Método para buscar en la lista productos la Coca Cola.
     * 
     * @return devuelve la lista de productos.
     * 
     */
    public List CargarCocaCola() {

        con = conexion.openConnection();
        List<Productos> Listaprod = new ArrayList();
        DefaultTableModel modelo = new DefaultTableModel();
        String sql = ("SELECT * FROM producto WHERE Nombre ='Coca Cola'");
        String[] datos = new String[5];
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Productos pro = new Productos();
                pro.setIDProducto(rs.getInt("IDProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setStock(rs.getInt("stock"));
                pro.setCategoria(rs.getString("categoria"));
                pro.setPrecio(rs.getString("precio"));
                Listaprod.add(pro);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return Listaprod;
    }
}

//{
// verificar cliente
//Select (tener datos de cliente, del habitual.) -- cliente habitual ;
//public Cliente getCliente (){
//String sentencia_borrar = ("SELECT * FROM cliente WHERE Habitual = 'S'");
//return Cliente;
//}

