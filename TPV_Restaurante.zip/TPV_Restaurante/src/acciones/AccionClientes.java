package acciones;

import gestionbd.ServiceCliente;
import gestionbd.ServiceProductos;
import gestionbd.ServiceVendedor;
import gestionbd.ServiceVenta;
import base.de.datos.ServicioClientes;
import gestionbd.Cliente;
import gestionbd.Productos;
import gestionbd.Login;
import gestionbd.Venta;
import gestionbd.Detalle;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import gestionbd.GestionSql;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AccionClientes extends javax.swing.JFrame {

    ServiceCliente cliente = new ServiceCliente();
    ServiceProductos producto = new ServiceProductos();
    ServiceVendedor vendedor = new ServiceVendedor();
    ServiceVenta ventas = new ServiceVenta();
    ServicioClientes service = new ServicioClientes();
    Cliente cl = new Cliente();
    Productos pro = new Productos();
    Login vend = new Login();
    Venta v = new Venta();
    Detalle dv = new Detalle();
    GestionSql con = new GestionSql();
    Connection conn = con.openConnection();
    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel tmp = new DefaultTableModel();
    ResultSet rs;
    int item;
    double Totalpagar = 0.00;
    public static GestionSql conexion = new GestionSql();
    PreparedStatement ps;
    Connection cone;
    int r;

    /**
     * Este método se usará para determinar que variables serán visibles en
     * nuestra interfaz y su colocación en pantalla.
     *
     */
    public AccionClientes() {
        initComponents();
        setLocationRelativeTo(null);
        txtIdCliente.setVisible(false);
        txtIdVenta.setVisible(false);
        lblIdProducto.setVisible(false);
        txtIdProducto.setVisible(false);
        txtIdCliente.setVisible(false);
        lblIdClientes.setVisible(false);
        txtIdVendedor.setVisible(false);
        lblIdVendedor.setVisible(false);
    }

    /**
     * Método para limpiar los campos de la tabla.
     *
     */
    public void limpiarTable() {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;
        }
    }

    /**
     * Método para limpiar las cajas de la tabla clientes.
     *
     */
    void limpiarCajas() {
        txtIdCliente.setText(null);
        txtDniCliente.setText(null);
        txtNombreCliente.setText(null);
        txtApellidosCliente.setText(null);
        txtDireccionCliente.setText(null);
        txtTelefonoCliente.setText(null);
        txtHabitualCliente.setText(null);
    }

    /**
     * Método para limpiar las cajas de la tabla productos.
     *
     */
    void limpiarCajasProductos() {
        txtIdProducto.setText(null);
        txtNombreProducto.setText(null);
        txtStockProducto.setText(null);
        txtCategoriaProducto.setText(null);
        txtPrecioProducto.setText(null);
    }

    /**
     * Método para limpiar las cajas de la tabla vendedor.
     *
     */
    void limpiarCajasVendedor() {
        txtIdVendedor.setText(null);
        txtDniVendedor.setText(null);
        txtNombreVendedor.setText(null);
        txtApellidosVendedor.setText(null);
        txtTelefonoVendedor.setText(null);
        txtPasswordVendedor.setText(null);
    }

    /**
     * Método para limpiar las cajas de la tabla venta.
     *
     */
    private void LimpiarVenta() {
        txtNombreNuevaVenta.setText("");
        txtDescripcionNuevaVenta.setText("");
        txtCantidadNuevaVenta.setText("");
        txtStockDisponibleNuevaVenta.setText("");
        txtPrecioNuevaVenta.setText("");
        txtIdVenta.setText(null);
    }

    /**
     * Método para guardar una nueva venta.
     *
     */
    private void saveVenta() {
        String cliente = txtClienteNuevaVenta.getText();
        String vendedor = lblVendedorMenu.getText();
        double total = Totalpagar;
        v.setCliente(cliente);
        v.setVendedor(vendedor);
        v.setSumaFinal(total);
        ventas.saveVenta(v);
    }

    /**
     * Método para guardar el detalle de la venta.
     *
     */
    private void saveDetalle() {
        int id = ventas.IdVenta();
        for (int i = 0; i < tableNuevaVenta.getRowCount(); i++) {
            String nombre = (tableNuevaVenta.getValueAt(i, 0).toString());
            int cant = Integer.parseInt(tableNuevaVenta.getValueAt(i, 2).toString());
            double precio = Double.parseDouble(tableNuevaVenta.getValueAt(i, 3).toString());
            dv.setNombre(nombre);
            dv.setCantidad(cant);
            dv.setPrecioVenta(precio);
            dv.setIdVentas(id);
            ventas.saveDetalle(dv);
        }
    }

    /**
     * Método para calcular el total a pagar.
     *
     */
    private void TotalPagar() {
        Totalpagar = 0.00;
        for (int i = 0; i < tableNuevaVenta.getRowCount(); i++) {
            double cal = Double.parseDouble(String.valueOf(tableNuevaVenta.getModel().getValueAt(i, 4)));
            Totalpagar = Totalpagar + cal;
        }
        lblTotalPagar.setText(String.format("%.2f", Totalpagar));
    }

    /**
     * Método para obtener los datos del cliente.
     *
     */
    public void getCliente() {
        List<Cliente> ListarCl = cliente.getCliente();
        modelo = (DefaultTableModel) tableClientes.getModel();
        Object[] ob = new Object[7];
        for (int i = 0; i < ListarCl.size(); i++) {
            ob[0] = ListarCl.get(i).getIDCliente();
            ob[1] = ListarCl.get(i).getDni();
            ob[2] = ListarCl.get(i).getNombre();
            ob[3] = ListarCl.get(i).getApellidos();
            ob[4] = ListarCl.get(i).getDireccion();
            ob[5] = ListarCl.get(i).getTelefono();
            ob[6] = ListarCl.get(i).getHabitual();
            modelo.addRow(ob);

        }
        tableClientes.setModel(modelo);
    }

    /**
     * Métódo para obtener los datos del producto.
     *
     */
    public void getProducto() {
        List<Productos> Listarpro = producto.getProducto();
        modelo = (DefaultTableModel) tableProductos.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarpro.size(); i++) {
            ob[0] = Listarpro.get(i).getIDProducto();
            ob[1] = Listarpro.get(i).getNombre();
            ob[2] = Listarpro.get(i).getStock();
            ob[3] = Listarpro.get(i).getCategoria();
            ob[4] = Listarpro.get(i).getPrecio();
            modelo.addRow(ob);

        }
        tableProductos.setModel(modelo);
    }

    /**
     * Método para obtener los datos del vendedor.
     *
     */
    public void getVendedor() {
        List<Login> Listavend = vendedor.getVendedor();
        modelo = (DefaultTableModel) tableVendedor.getModel();
        Object[] ob = new Object[6];
        for (int i = 0; i < Listavend.size(); i++) {
            ob[0] = Listavend.get(i).getIDVendedor();
            ob[1] = Listavend.get(i).getDni();
            ob[2] = Listavend.get(i).getNombre();
            ob[3] = Listavend.get(i).getApellidos();
            ob[4] = Listavend.get(i).getTelefono();
            ob[5] = Listavend.get(i).getPassword();
            modelo.addRow(ob);

        }
        tableVendedor.setModel(modelo);
    }

    /**
     * Método para obtener los datos de la venta.
     *
     */
    public void getVenta() {
        List<Venta> Listavent = ventas.getVenta();
        modelo = (DefaultTableModel) tableVentas.getModel();
        Object[] ob = new Object[3];
        for (int i = 0; i < Listavent.size(); i++) {

            ob[0] = Listavent.get(i).getCliente();
            ob[1] = Listavent.get(i).getVendedor();
            ob[2] = Listavent.get(i).getSumaFinal();
            modelo.addRow(ob);

        }
        tableVentas.setModel(modelo);
    }

    /**
     * Método para actualizar el stock de la tabla productos.
     *
     */
    private void actualizarStock() {
        for (int i = 0; i < tableNuevaVenta.getRowCount(); i++) {
            String nom = tableNuevaVenta.getValueAt(i, 0).toString();
            int cant = Integer.parseInt(tableNuevaVenta.getValueAt(i, 2).toString());
            pro = service.BuscarPro(nom);
            int stockActual = pro.getStock() - cant;
            ventas.actualizarStock(stockActual, nom);
        }
    }

    /**
     * Método para limpiar los datos de la tabla venta.
     *
     */
    private void LimpiarTableVenta() {
        tmp = (DefaultTableModel) tableNuevaVenta.getModel();
        int filas = tableNuevaVenta.getRowCount();
        for (int i = 0; i < filas; i++) {
            tmp.removeRow(0);
        }
    }

    /**
     * Método para limpiar los datos del cliente.
     *
     */
    private void LimpiarClienteVenta() {
        txtDniNuevaVenta.setText("");
        txtDniCliente.setText("");
        txtNombreCliente.setText("");
        txtApellidosCliente.setText("");
        txtDireccionCliente.setText("");
        txtTelefonoCliente.setText("");
        txtHabitualCliente.setText("");
    }

    /**
     * Método para cargar los datos del producto Coca cola.
     *
     */
    public void CargarCocaCola() {
        List<Productos> Listarprod = service.CargarCocaCola();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Fanta.
     *
     */

    public void CargarFanta() {
        List<Productos> Listarprod = service.CargarFanta();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Rodaballo.
     *
     */

    public void CargarRodaballo() {
        List<Productos> Listarprod = service.CargarRodaballo();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Lubina.
     *
     */

    public void CargarLubina() {
        List<Productos> Listarprod = service.CargarLubina();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Besugo.
     *
     */

    public void CargarBesugo() {
        List<Productos> Listarprod = service.CargarBesugo();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Croquetas.
     *
     */

    public void CargarCroquetas() {
        List<Productos> Listarprod = service.CargarCroquetas();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Patatas Fritas.
     *
     */

    public void CargarPatatasFritas() {
        List<Productos> Listarprod = service.CargarPatatasFritas();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Cafe con Leche.
     *
     */
    public void CargarCafeLeche() {
        List<Productos> Listarprod = service.CargarCafeLeche();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Cafe solo.
     *
     */
    public void CargarCafeSolo() {
        List<Productos> Listarprod = service.CargarCafeSolo();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    /**
     * Método para cargar los datos del producto Filete.
     *
     */

    public void CargarFilete() {

        List<Productos> Listarprod = service.CargarFilete();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);

    }

    /**
     * Método para cargar los datos del producto Hamburguesa.
     *
     */

    public void CargarHamburguesa() {
        List<Productos> Listarprod = service.CargarHamburguesa();
        modelo = (DefaultTableModel) tableNuevaVenta.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listarprod.size(); i++) {
            ob[0] = Listarprod.get(i).getNombre();
            ob[1] = Listarprod.get(i).getCategoria();
            ob[2] = Listarprod.get(i).getCantidad();
            ob[3] = Listarprod.get(i).getPrecio();
            ob[4] = Listarprod.get(i).getPrecio();
            modelo.addRow(ob);
        }
        tableNuevaVenta.setModel(modelo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelIzq = new javax.swing.JPanel();
        btnClientes = new javax.swing.JButton();
        btnProductos = new javax.swing.JButton();
        btnVentas = new javax.swing.JButton();
        btnNuevaVenta = new javax.swing.JButton();
        lblIconoRestaurante = new javax.swing.JLabel();
        btnVendedor = new javax.swing.JButton();
        lblVendedorMenu = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();
        lineaDivisoria = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        lblNombreNuevaVenta = new javax.swing.JLabel();
        lblDescripcionNuevaVenta = new javax.swing.JLabel();
        lblCantidadNuevaVenta = new javax.swing.JLabel();
        lblPrecioNuevaVenta = new javax.swing.JLabel();
        lblStockDisponibleNuevaVenta = new javax.swing.JLabel();
        btnEliminarNuevaVenta = new javax.swing.JButton();
        txtNombreNuevaVenta = new javax.swing.JTextField();
        txtDescripcionNuevaVenta = new javax.swing.JTextField();
        txtCantidadNuevaVenta = new javax.swing.JTextField();
        txtPrecioNuevaVenta = new javax.swing.JTextField();
        txtStockDisponibleNuevaVenta = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableNuevaVenta = new javax.swing.JTable();
        lblTotalPagarNuevaVenta = new javax.swing.JLabel();
        lblTotalPagar = new javax.swing.JLabel();
        lblDniNuevaVenta = new javax.swing.JLabel();
        txtDniNuevaVenta = new javax.swing.JTextField();
        lblClienteNuevaVenta = new javax.swing.JLabel();
        txtClienteNuevaVenta = new javax.swing.JTextField();
        txtApellidosNuevaVenta = new javax.swing.JTextField();
        txtDireccionNuevaVenta = new javax.swing.JTextField();
        txtTelefonoNuevaVenta = new javax.swing.JTextField();
        lblTelefonoNuevaVenta = new javax.swing.JLabel();
        lblDireccionNuevaVenta = new javax.swing.JLabel();
        lblApellidosNuevaVenta = new javax.swing.JLabel();
        btnGuardarNuevaVenta = new javax.swing.JButton();
        txtIdVenta = new javax.swing.JTextField();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        btnHamburguesa = new javax.swing.JButton();
        btnFilete = new javax.swing.JButton();
        lblHamburguesa = new javax.swing.JLabel();
        lblFilete = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        btnCafeSolo = new javax.swing.JButton();
        btnCafeLeche = new javax.swing.JButton();
        lblCafeSolo = new javax.swing.JLabel();
        lblCafeConLeche = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        btnPatatasFritas = new javax.swing.JButton();
        btnCroquetas = new javax.swing.JButton();
        lblPatatasFritas = new javax.swing.JLabel();
        lblCroquetas = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        btnLubina = new javax.swing.JButton();
        btnRodaballo = new javax.swing.JButton();
        btnBesugo = new javax.swing.JButton();
        lblLubina = new javax.swing.JLabel();
        lblRodaballo = new javax.swing.JLabel();
        lblBesugo = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        btnCocaCola = new javax.swing.JButton();
        btnFanta = new javax.swing.JButton();
        lblCocaCola = new javax.swing.JLabel();
        lblFanta = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblDniCliente = new javax.swing.JLabel();
        lblNombreCliente = new javax.swing.JLabel();
        lblApellidosCliente = new javax.swing.JLabel();
        lblDireccionCliente = new javax.swing.JLabel();
        txtDniCliente = new javax.swing.JTextField();
        txtNombreCliente = new javax.swing.JTextField();
        txtApellidosCliente = new javax.swing.JTextField();
        txtDireccionCliente = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableClientes = new javax.swing.JTable();
        lblTelefonoCliente = new javax.swing.JLabel();
        txtTelefonoCliente = new javax.swing.JTextField();
        btnGuardarCliente = new javax.swing.JButton();
        btnActualizarCliente = new javax.swing.JButton();
        btnEliminarCliente = new javax.swing.JButton();
        btnLimpiarCliente = new javax.swing.JButton();
        lblIdClientes = new javax.swing.JLabel();
        txtIdCliente = new javax.swing.JTextField();
        txtHabitualCliente = new javax.swing.JTextField();
        lblHabitualCliente = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblName = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        lblStock = new javax.swing.JLabel();
        lblCategoriaProducto = new javax.swing.JLabel();
        txtNombreProducto = new javax.swing.JTextField();
        txtPrecioProducto = new javax.swing.JTextField();
        txtStockProducto = new javax.swing.JTextField();
        txtCategoriaProducto = new javax.swing.JTextField();
        btnGuardarProductos = new javax.swing.JButton();
        btnActualizarProductos = new javax.swing.JButton();
        btnEliminarProductos = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableProductos = new javax.swing.JTable();
        lblIdProducto = new javax.swing.JLabel();
        txtIdProducto = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tableVentas = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        lblIdVendedor = new javax.swing.JLabel();
        txtIdVendedor = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tableVendedor = new javax.swing.JTable();
        lblDniVendedor = new javax.swing.JLabel();
        lblNombreVendedor = new javax.swing.JLabel();
        lblApellidosVendedor = new javax.swing.JLabel();
        lblTelefonoVendedor = new javax.swing.JLabel();
        lblPasswordVendedor = new javax.swing.JLabel();
        btnGuardarVendedor = new javax.swing.JButton();
        btnActualizarVendedor = new javax.swing.JButton();
        btnEliminarVendedor = new javax.swing.JButton();
        btnLimpiarVendedor = new javax.swing.JButton();
        txtDniVendedor = new javax.swing.JTextField();
        txtNombreVendedor = new javax.swing.JTextField();
        txtApellidosVendedor = new javax.swing.JTextField();
        txtTelefonoVendedor = new javax.swing.JTextField();
        txtPasswordVendedor = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelIzq.setBackground(new java.awt.Color(204, 204, 255));

        btnClientes.setText("Clientes");
        btnClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClientesActionPerformed(evt);
            }
        });

        btnProductos.setText("Productos");
        btnProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductosActionPerformed(evt);
            }
        });

        btnVentas.setText("Ventas");
        btnVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentasActionPerformed(evt);
            }
        });

        btnNuevaVenta.setText("Nueva Venta");
        btnNuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevaVentaActionPerformed(evt);
            }
        });

        lblIconoRestaurante.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/iconoRest.png"))); // NOI18N

        btnVendedor.setText("Vendedor");
        btnVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendedorActionPerformed(evt);
            }
        });

        lblVendedorMenu.setText("TPV Restaurante");

        javax.swing.GroupLayout panelIzqLayout = new javax.swing.GroupLayout(panelIzq);
        panelIzq.setLayout(panelIzqLayout);
        panelIzqLayout.setHorizontalGroup(
            panelIzqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelIzqLayout.createSequentialGroup()
                .addGroup(panelIzqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblIconoRestaurante, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNuevaVenta)
                    .addComponent(btnClientes)
                    .addComponent(btnProductos)
                    .addComponent(btnVentas)
                    .addComponent(btnVendedor)
                    .addComponent(lblVendedorMenu))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelIzqLayout.setVerticalGroup(
            panelIzqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelIzqLayout.createSequentialGroup()
                .addComponent(lblIconoRestaurante)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblVendedorMenu)
                .addGap(38, 38, 38)
                .addComponent(btnNuevaVenta)
                .addGap(38, 38, 38)
                .addComponent(btnClientes)
                .addGap(32, 32, 32)
                .addComponent(btnProductos)
                .addGap(35, 35, 35)
                .addComponent(btnVentas)
                .addGap(46, 46, 46)
                .addComponent(btnVendedor)
                .addContainerGap(89, Short.MAX_VALUE))
        );

        getContentPane().add(panelIzq, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 130, 580));

        lblTitulo.setFont(new java.awt.Font("Verdana", 1, 36)); // NOI18N
        lblTitulo.setText("TPV RESTAURANTE");
        getContentPane().add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 400, 30));

        lineaDivisoria.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout lineaDivisoriaLayout = new javax.swing.GroupLayout(lineaDivisoria);
        lineaDivisoria.setLayout(lineaDivisoriaLayout);
        lineaDivisoriaLayout.setHorizontalGroup(
            lineaDivisoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 660, Short.MAX_VALUE)
        );
        lineaDivisoriaLayout.setVerticalGroup(
            lineaDivisoriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        getContentPane().add(lineaDivisoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 660, 10));

        lblNombreNuevaVenta.setText("Nombre");

        lblDescripcionNuevaVenta.setText("Descripcion");

        lblCantidadNuevaVenta.setText("Cantidad");

        lblPrecioNuevaVenta.setText("Precio");

        lblStockDisponibleNuevaVenta.setText("Stock disponible");

        btnEliminarNuevaVenta.setText("Eliminar");
        btnEliminarNuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarNuevaVentaActionPerformed(evt);
            }
        });

        txtNombreNuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreNuevaVentaActionPerformed(evt);
            }
        });
        txtNombreNuevaVenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNombreNuevaVentaKeyPressed(evt);
            }
        });

        txtCantidadNuevaVenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCantidadNuevaVentaKeyPressed(evt);
            }
        });

        tableNuevaVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Descripción", "Cantidad", "Precio", "TOTAL"
            }
        ));
        jScrollPane1.setViewportView(tableNuevaVenta);
        if (tableNuevaVenta.getColumnModel().getColumnCount() > 0) {
            tableNuevaVenta.getColumnModel().getColumn(0).setPreferredWidth(70);
            tableNuevaVenta.getColumnModel().getColumn(1).setPreferredWidth(70);
            tableNuevaVenta.getColumnModel().getColumn(2).setPreferredWidth(30);
            tableNuevaVenta.getColumnModel().getColumn(3).setPreferredWidth(30);
            tableNuevaVenta.getColumnModel().getColumn(4).setPreferredWidth(30);
        }

        lblTotalPagarNuevaVenta.setText("Total a pagar");

        lblTotalPagar.setText("-----");

        lblDniNuevaVenta.setText("DNI");

        txtDniNuevaVenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDniNuevaVentaKeyPressed(evt);
            }
        });

        lblClienteNuevaVenta.setText("Nombre");

        txtDireccionNuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionNuevaVentaActionPerformed(evt);
            }
        });

        lblTelefonoNuevaVenta.setText("Telefono");

        lblDireccionNuevaVenta.setText("Direccion");

        lblApellidosNuevaVenta.setText("Apellidos");

        btnGuardarNuevaVenta.setText("Guardar Venta");
        btnGuardarNuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarNuevaVentaActionPerformed(evt);
            }
        });

        btnHamburguesa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Burger.jpg"))); // NOI18N
        btnHamburguesa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnHamburguesaMouseClicked(evt);
            }
        });
        btnHamburguesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHamburguesaActionPerformed(evt);
            }
        });

        btnFilete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Ternera.jpg"))); // NOI18N
        btnFilete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFileteActionPerformed(evt);
            }
        });

        lblHamburguesa.setText("Hamburguesa");

        lblFilete.setText("Filete de Ternera");
        lblFilete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblFileteMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnHamburguesa, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblHamburguesa))
                .addGap(52, 52, 52)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFilete)
                    .addComponent(btnFilete, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnFilete, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnHamburguesa, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFilete)
                    .addComponent(lblHamburguesa))
                .addContainerGap(135, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Comidas", jPanel6);

        btnCafeSolo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caf__solo.jpg"))); // NOI18N
        btnCafeSolo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCafeSoloActionPerformed(evt);
            }
        });

        btnCafeLeche.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cafeleche.jpg"))); // NOI18N
        btnCafeLeche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCafeLecheActionPerformed(evt);
            }
        });

        lblCafeSolo.setText("Cafe Solo");

        lblCafeConLeche.setText("Cafe Con Leche");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(btnCafeSolo, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(btnCafeLeche, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(lblCafeSolo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblCafeConLeche)))
                .addContainerGap(110, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCafeLeche, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCafeSolo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCafeSolo)
                    .addComponent(lblCafeConLeche))
                .addContainerGap(154, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Cafes", jPanel7);

        btnPatatasFritas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/patatas.jpg"))); // NOI18N
        btnPatatasFritas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPatatasFritasActionPerformed(evt);
            }
        });

        btnCroquetas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/croquetas.jpeg"))); // NOI18N
        btnCroquetas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCroquetasActionPerformed(evt);
            }
        });

        lblPatatasFritas.setText("Patatas Fritas");

        lblCroquetas.setText("Croquetas");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblPatatasFritas)
                    .addComponent(btnPatatasFritas, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(btnCroquetas, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(lblCroquetas, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(113, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCroquetas)
                    .addComponent(btnPatatasFritas, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblCroquetas)
                    .addComponent(lblPatatasFritas))
                .addContainerGap(138, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Tapas", jPanel8);

        btnLubina.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/lubina.jpg"))); // NOI18N
        btnLubina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLubinaActionPerformed(evt);
            }
        });

        btnRodaballo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rodaballo.jpg"))); // NOI18N
        btnRodaballo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRodaballoActionPerformed(evt);
            }
        });

        btnBesugo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/besugo_01.jpg"))); // NOI18N
        btnBesugo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBesugoActionPerformed(evt);
            }
        });

        lblLubina.setText("Lubina");

        lblRodaballo.setText("Rodaballo");

        lblBesugo.setText("Besugo");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnLubina, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRodaballo, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBesugo, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(lblLubina)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblRodaballo)
                .addGap(42, 42, 42)
                .addComponent(lblBesugo)
                .addGap(62, 62, 62))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnLubina)
                            .addComponent(btnRodaballo, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(btnBesugo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblBesugo)
                        .addComponent(lblRodaballo))
                    .addComponent(lblLubina))
                .addContainerGap(144, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Pescados", jPanel9);

        btnCocaCola.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cocacola.jpg"))); // NOI18N
        btnCocaCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCocaColaActionPerformed(evt);
            }
        });

        btnFanta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fanta.jpg"))); // NOI18N
        btnFanta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFantaActionPerformed(evt);
            }
        });

        lblCocaCola.setText("Coca Cola");

        lblFanta.setText("Fanta");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCocaCola, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(lblCocaCola)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFanta, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(lblFanta)))
                .addGap(160, 160, 160))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCocaCola, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFanta, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFanta)
                    .addComponent(lblCocaCola))
                .addContainerGap(140, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Bebidas", jPanel10);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNombreNuevaVenta)
                            .addComponent(txtNombreNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDescripcionNuevaVenta)
                            .addComponent(txtDescripcionNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCantidadNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblCantidadNuevaVenta))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPrecioNuevaVenta)
                            .addComponent(txtPrecioNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblStockDisponibleNuevaVenta)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtStockDisponibleNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtIdVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(159, 159, 159))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDniNuevaVenta)
                            .addComponent(txtDniNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtClienteNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblClienteNuevaVenta))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblApellidosNuevaVenta)
                            .addComponent(txtApellidosNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDireccionNuevaVenta)
                            .addComponent(txtDireccionNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblTelefonoNuevaVenta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTelefonoNuevaVenta))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblTotalPagarNuevaVenta)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnGuardarNuevaVenta))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(lblTotalPagar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnEliminarNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 440, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane2)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblStockDisponibleNuevaVenta)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblNombreNuevaVenta)
                        .addComponent(lblDescripcionNuevaVenta)
                        .addComponent(lblCantidadNuevaVenta)
                        .addComponent(lblPrecioNuevaVenta)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPrecioNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCantidadNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDescripcionNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombreNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtStockDisponibleNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblDniNuevaVenta)
                                .addComponent(lblClienteNuevaVenta))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblTelefonoNuevaVenta)
                                .addComponent(lblDireccionNuevaVenta)
                                .addComponent(lblTotalPagarNuevaVenta)
                                .addComponent(btnGuardarNuevaVenta))))
                    .addComponent(lblApellidosNuevaVenta))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtClienteNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDniNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtApellidosNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDireccionNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelefonoNuevaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTotalPagar)
                    .addComponent(btnEliminarNuevaVenta))
                .addContainerGap())
        );

        jTabbedPane1.addTab("1", jPanel1);

        lblDniCliente.setText("DNI");

        lblNombreCliente.setText("Nombre");

        lblApellidosCliente.setText("Apellidos");

        lblDireccionCliente.setText("Direccion");

        tableClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "DNI", "Nombre", "Apellidos", "Direccion", "Telefono", "Habitual"
            }
        ));
        tableClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableClientesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableClientes);
        if (tableClientes.getColumnModel().getColumnCount() > 0) {
            tableClientes.getColumnModel().getColumn(0).setPreferredWidth(10);
            tableClientes.getColumnModel().getColumn(1).setPreferredWidth(50);
            tableClientes.getColumnModel().getColumn(2).setPreferredWidth(100);
            tableClientes.getColumnModel().getColumn(3).setPreferredWidth(50);
            tableClientes.getColumnModel().getColumn(4).setPreferredWidth(80);
            tableClientes.getColumnModel().getColumn(5).setPreferredWidth(50);
        }

        lblTelefonoCliente.setText("Telefono");

        btnGuardarCliente.setText("Guardar");
        btnGuardarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarClienteActionPerformed(evt);
            }
        });

        btnActualizarCliente.setText("Actualizar");
        btnActualizarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarClienteActionPerformed(evt);
            }
        });

        btnEliminarCliente.setText("Elinimar");
        btnEliminarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarClienteActionPerformed(evt);
            }
        });

        btnLimpiarCliente.setText("Limpiar");
        btnLimpiarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarClienteActionPerformed(evt);
            }
        });

        lblIdClientes.setText("ID");

        lblHabitualCliente.setText("Habitual");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDniCliente)
                            .addComponent(lblNombreCliente)
                            .addComponent(lblApellidosCliente)
                            .addComponent(lblDireccionCliente)
                            .addComponent(lblTelefonoCliente)
                            .addComponent(lblIdClientes))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDireccionCliente)
                            .addComponent(txtApellidosCliente)
                            .addComponent(txtNombreCliente)
                            .addComponent(txtDniCliente)
                            .addComponent(txtTelefonoCliente)
                            .addComponent(txtIdCliente)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnEliminarCliente)
                            .addComponent(btnGuardarCliente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lblHabitualCliente)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtHabitualCliente, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnActualizarCliente)
                            .addComponent(btnLimpiarCliente))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 632, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(26, 26, 26))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(lblIdClientes)
                                .addGap(20, 20, 20))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(txtIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblDniCliente)
                            .addComponent(txtDniCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNombreCliente)
                            .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblApellidosCliente)
                            .addComponent(txtApellidosCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDireccionCliente)
                            .addComponent(txtDireccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTelefonoCliente)
                            .addComponent(txtTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtHabitualCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblHabitualCliente))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnGuardarCliente)
                            .addComponent(btnActualizarCliente))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEliminarCliente)
                            .addComponent(btnLimpiarCliente))
                        .addGap(41, 41, 41))))
        );

        jTabbedPane1.addTab("2", jPanel2);

        lblName.setText("Nombre");

        lblPrice.setText("Precio");

        lblStock.setText("Stock");

        lblCategoriaProducto.setText("Categoria");

        btnGuardarProductos.setText("Guardar");
        btnGuardarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarProductosActionPerformed(evt);
            }
        });

        btnActualizarProductos.setText("Actualizar");
        btnActualizarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarProductosActionPerformed(evt);
            }
        });

        btnEliminarProductos.setText("Eliminar");
        btnEliminarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarProductosActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        tableProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Stock", "Categoria", "Precio"
            }
        ));
        tableProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableProductosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tableProductos);
        if (tableProductos.getColumnModel().getColumnCount() > 0) {
            tableProductos.getColumnModel().getColumn(0).setPreferredWidth(10);
            tableProductos.getColumnModel().getColumn(1).setPreferredWidth(100);
            tableProductos.getColumnModel().getColumn(2).setPreferredWidth(100);
            tableProductos.getColumnModel().getColumn(4).setPreferredWidth(50);
        }

        lblIdProducto.setText("ID");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblStock)
                            .addComponent(lblCategoriaProducto))
                        .addGap(37, 37, 37)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtStockProducto, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
                            .addComponent(txtCategoriaProducto)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnGuardarProductos)
                            .addComponent(btnEliminarProductos))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(btnLimpiar)
                                .addGap(31, 31, 31))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnActualizarProductos)
                                .addGap(18, 18, 18)))
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 581, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPrice)
                            .addComponent(lblName)
                            .addComponent(lblIdProducto))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIdProducto)
                    .addComponent(txtIdProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName)
                    .addComponent(txtNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPrice)
                    .addComponent(txtPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblStock)
                    .addComponent(txtStockProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCategoriaProducto)
                    .addComponent(txtCategoriaProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarProductos)
                    .addComponent(btnActualizarProductos))
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminarProductos)
                    .addComponent(btnLimpiar))
                .addGap(36, 36, 36))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("3", jPanel3);

        tableVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cliente", "Vendedor", "Suma Final"
            }
        ));
        jScrollPane4.setViewportView(tableVentas);
        if (tableVentas.getColumnModel().getColumnCount() > 0) {
            tableVentas.getColumnModel().getColumn(0).setPreferredWidth(50);
        }

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 815, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("4", jPanel4);

        lblIdVendedor.setText("ID");

        tableVendedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "DNI", "Nombre", "Apellidos", "Telefono", "Password"
            }
        ));
        tableVendedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableVendedorMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tableVendedor);

        lblDniVendedor.setText("DNI");

        lblNombreVendedor.setText("Nombre");

        lblApellidosVendedor.setText("Apellidos");

        lblTelefonoVendedor.setText("Telefono");

        lblPasswordVendedor.setText("Password");

        btnGuardarVendedor.setText("Guardar");
        btnGuardarVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarVendedorActionPerformed(evt);
            }
        });

        btnActualizarVendedor.setText("Actualizar");
        btnActualizarVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarVendedorActionPerformed(evt);
            }
        });

        btnEliminarVendedor.setText("Eliminar");
        btnEliminarVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarVendedorActionPerformed(evt);
            }
        });

        btnLimpiarVendedor.setText("Limpiar");
        btnLimpiarVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarVendedorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lblIdVendedor))
                            .addComponent(lblDniVendedor)
                            .addComponent(lblApellidosVendedor))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtApellidosVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtNombreVendedor, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtDniVendedor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(txtTelefonoVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtPasswordVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtIdVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(lblNombreVendedor)
                    .addComponent(lblTelefonoVendedor)
                    .addComponent(lblPasswordVendedor)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btnGuardarVendedor)
                        .addGap(18, 18, 18)
                        .addComponent(btnActualizarVendedor))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btnEliminarVendedor)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnLimpiarVendedor)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 635, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIdVendedor)
                    .addComponent(txtIdVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDniVendedor)
                    .addComponent(txtDniVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreVendedor)
                    .addComponent(txtNombreVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblApellidosVendedor)
                    .addComponent(txtApellidosVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTelefonoVendedor)
                    .addComponent(txtTelefonoVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPasswordVendedor)
                    .addComponent(txtPasswordVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarVendedor)
                    .addComponent(btnActualizarVendedor))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminarVendedor)
                    .addComponent(btnLimpiarVendedor))
                .addContainerGap(65, Short.MAX_VALUE))
            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("5", jPanel5);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 850, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarClienteActionPerformed
        if (!"".equals(txtDniCliente.getText()) || !"".equals(txtNombreCliente.getText()) || !"".equals(txtApellidosCliente.getText()) || !"".equals(txtDireccionCliente.getText()) || !"".equals(txtTelefonoCliente.getText()) || !"".equals(txtHabitualCliente.getText())) {

            cl.setDni((txtDniCliente.getText()));
            cl.setNombre((txtNombreCliente.getText()));
            cl.setApellidos((txtApellidosCliente.getText()));
            cl.setDireccion((txtDireccionCliente.getText()));
            cl.setTelefono((txtTelefonoCliente.getText()));
            cl.setHabitual((txtHabitualCliente.getText()));
            cliente.saveCliente(cl);
            limpiarTable();
            limpiarCajas();
            getCliente();
            JOptionPane.showMessageDialog(null, "Cliente guardado correctamente");

        } else {
            JOptionPane.showMessageDialog(null, "Cliente no guardado");
        }
    }//GEN-LAST:event_btnGuardarClienteActionPerformed

    private void btnLimpiarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarClienteActionPerformed
        limpiarCajas();
    }//GEN-LAST:event_btnLimpiarClienteActionPerformed

    private void btnClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientesActionPerformed
        limpiarTable();
        getCliente();
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_btnClientesActionPerformed

    private void btnEliminarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarClienteActionPerformed

        if (!"".equals(txtIdCliente.getText())) {
            int pregunta = JOptionPane.showConfirmDialog(this, "Esta seguro de eliminar");
            if (pregunta == 0) {
                int id = Integer.parseInt(txtIdCliente.getText());
                cliente.deleteCliente(id);
                limpiarTable();
                limpiarCajas();
                getCliente();
            }
        }
    }//GEN-LAST:event_btnEliminarClienteActionPerformed

    private void tableClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableClientesMouseClicked
        int fila = tableClientes.rowAtPoint(evt.getPoint());
        txtIdCliente.setText(tableClientes.getValueAt(fila, 0).toString());
        txtDniCliente.setText(tableClientes.getValueAt(fila, 1).toString());
        txtNombreCliente.setText(tableClientes.getValueAt(fila, 2).toString());
        txtApellidosCliente.setText(tableClientes.getValueAt(fila, 3).toString());
        txtDireccionCliente.setText(tableClientes.getValueAt(fila, 4).toString());
        txtTelefonoCliente.setText(tableClientes.getValueAt(fila, 5).toString());
        txtHabitualCliente.setText(tableClientes.getValueAt(fila, 6).toString());

    }//GEN-LAST:event_tableClientesMouseClicked

    private void btnActualizarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarClienteActionPerformed
        if ("".equals(txtIdCliente.getText())) {
            JOptionPane.showMessageDialog(null, "selecciona una fila");
        } else {

            if (!"".equals(txtDniCliente.getText()) || !"".equals(txtNombreCliente.getText()) || !"".equals(txtApellidosCliente.getText()) || !"".equals(txtDireccionCliente.getText()) || !"".equals(txtTelefonoCliente.getText()) || !"".equals(txtHabitualCliente.getText())) {
                cl.setDni(txtDniCliente.getText());
                cl.setNombre(txtNombreCliente.getText());
                cl.setApellidos(txtApellidosCliente.getText());
                cl.setDireccion(txtDireccionCliente.getText());
                cl.setTelefono(txtTelefonoCliente.getText());
                cl.setHabitual(txtHabitualCliente.getText());
                cl.setIDCliente(Integer.parseInt(txtIdCliente.getText()));
                cliente.updateCliente(cl);
                limpiarTable();
                limpiarCajas();
                getCliente();
            } else {
                JOptionPane.showMessageDialog(null, "Los campos estan vacios");
            }
        }
    }//GEN-LAST:event_btnActualizarClienteActionPerformed

    private void btnGuardarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarProductosActionPerformed
        if (!"".equals(txtNombreProducto.getText()) || !"".equals(txtStockProducto.getText()) || !"".equals(txtCategoriaProducto.getText()) || !"".equals(txtPrecioProducto.getText())) {

            pro.setNombre((txtNombreProducto.getText()));
            pro.setStock(Integer.parseInt(txtStockProducto.getText()));
            pro.setCategoria((txtCategoriaProducto.getText()));
            pro.setPrecio((txtPrecioProducto.getText()));
            producto.saveProducto(pro);
            limpiarTable();
            limpiarCajasProductos();
            getProducto();
            JOptionPane.showMessageDialog(null, "Producto guardado correctamente");

        } else {
            JOptionPane.showMessageDialog(null, "Producto no guardado");
        }

    }//GEN-LAST:event_btnGuardarProductosActionPerformed

    private void tableProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableProductosMouseClicked

        int fila = tableProductos.rowAtPoint(evt.getPoint());
        txtIdProducto.setText(tableProductos.getValueAt(fila, 0).toString());
        txtNombreProducto.setText(tableProductos.getValueAt(fila, 1).toString());
        txtStockProducto.setText(tableProductos.getValueAt(fila, 2).toString());
        txtCategoriaProducto.setText(tableProductos.getValueAt(fila, 3).toString());
        txtPrecioProducto.setText(tableProductos.getValueAt(fila, 4).toString());

    }//GEN-LAST:event_tableProductosMouseClicked

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiarCajasProductos();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductosActionPerformed
        limpiarTable();
        getProducto();
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_btnProductosActionPerformed

    private void btnEliminarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarProductosActionPerformed
        if (!"".equals(txtIdProducto.getText())) {
            int pregunta = JOptionPane.showConfirmDialog(this, "Esta seguro de eliminar");
            if (pregunta == 0) {
                int id = Integer.parseInt(txtIdProducto.getText());
                producto.deleteProducto(id);
                limpiarTable();
                limpiarCajasProductos();
                getProducto();
            }
        }
    }//GEN-LAST:event_btnEliminarProductosActionPerformed

    private void btnActualizarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarProductosActionPerformed
        if ("".equals(txtIdProducto.getText())) {
            JOptionPane.showMessageDialog(null, "selecciona una fila");
        } else {

            if (!"".equals(txtNombreProducto.getText()) || !"".equals(txtStockProducto.getText()) || !"".equals(txtCategoriaProducto.getText()) || !"".equals(txtPrecioProducto.getText())) {
                pro.setNombre(txtNombreProducto.getText());
                pro.setStock(Integer.parseInt(txtStockProducto.getText()));
                pro.setCategoria(txtCategoriaProducto.getText());
                pro.setPrecio(txtPrecioProducto.getText());
                pro.setIDProducto(Integer.parseInt(txtIdProducto.getText()));
                producto.updateProducto(pro);
                limpiarTable();
                limpiarCajasProductos();
                getProducto();
            } else {
                JOptionPane.showMessageDialog(null, "Los campos estan vacios");
            }
        }
    }//GEN-LAST:event_btnActualizarProductosActionPerformed

    private void btnGuardarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarVendedorActionPerformed
        if (!"".equals(txtDniVendedor.getText()) || !"".equals(txtNombreVendedor.getText()) || !"".equals(txtApellidosVendedor.getText()) || !"".equals(txtTelefonoVendedor.getText()) || !"".equals(txtPasswordVendedor.getText())) {

            vend.setDni((txtDniVendedor.getText()));
            vend.setNombre((txtNombreVendedor.getText()));
            vend.setApellidos((txtApellidosVendedor.getText()));
            vend.setTelefono((txtTelefonoVendedor.getText()));
            vend.setPassword((txtPasswordVendedor.getText()));
            vendedor.saveVendedor(vend);
            limpiarTable();
            limpiarCajasVendedor();
            getVendedor();
            JOptionPane.showMessageDialog(null, "Vendedor guardado correctamente");

        } else {
            JOptionPane.showMessageDialog(null, "Vendedor no guardado");
        }

    }//GEN-LAST:event_btnGuardarVendedorActionPerformed

    private void btnLimpiarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarVendedorActionPerformed
        limpiarCajasVendedor();
    }//GEN-LAST:event_btnLimpiarVendedorActionPerformed

    private void btnActualizarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarVendedorActionPerformed
        if ("".equals(txtIdVendedor.getText())) {
            JOptionPane.showMessageDialog(null, "selecciona una fila");
        } else {

            if (!"".equals(txtDniVendedor.getText()) || !"".equals(txtNombreVendedor.getText()) || !"".equals(txtApellidosVendedor.getText()) || !"".equals(txtTelefonoVendedor.getText()) || !"".equals(txtPasswordVendedor.getText())) {
                vend.setDni(txtDniVendedor.getText());
                vend.setNombre(txtNombreVendedor.getText());
                vend.setApellidos(txtApellidosVendedor.getText());
                vend.setTelefono(txtTelefonoVendedor.getText());
                vend.setPassword(txtPasswordVendedor.getText());
                vend.setIDVendedor(Integer.parseInt(txtIdVendedor.getText()));
                vendedor.updateVendedor(vend);
                limpiarTable();
                limpiarCajasVendedor();
                getVendedor();
            } else {
                JOptionPane.showMessageDialog(null, "Los campos estan vacios");
            }
        }
    }//GEN-LAST:event_btnActualizarVendedorActionPerformed

    private void tableVendedorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableVendedorMouseClicked
        int fila = tableVendedor.rowAtPoint(evt.getPoint());
        txtIdVendedor.setText(tableVendedor.getValueAt(fila, 0).toString());
        txtDniVendedor.setText(tableVendedor.getValueAt(fila, 1).toString());
        txtNombreVendedor.setText(tableVendedor.getValueAt(fila, 2).toString());
        txtApellidosVendedor.setText(tableVendedor.getValueAt(fila, 3).toString());
        txtTelefonoVendedor.setText(tableVendedor.getValueAt(fila, 4).toString());
        txtPasswordVendedor.setText(tableVendedor.getValueAt(fila, 5).toString());

    }//GEN-LAST:event_tableVendedorMouseClicked

    private void btnVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendedorActionPerformed
        limpiarTable();
        getVendedor();
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_btnVendedorActionPerformed

    private void btnEliminarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarVendedorActionPerformed
        if (!"".equals(txtIdVendedor.getText())) {
            int pregunta = JOptionPane.showConfirmDialog(this, "Esta seguro de eliminar");
            if (pregunta == 0) {
                int id = Integer.parseInt(txtIdVendedor.getText());
                vendedor.deleteVendedor(id);
                limpiarTable();
                limpiarCajasVendedor();
                getVendedor();
            }
        }
    }//GEN-LAST:event_btnEliminarVendedorActionPerformed

    private void txtNombreNuevaVentaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreNuevaVentaKeyPressed

        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!"".equals(txtNombreNuevaVenta.getText())) {
                String nom = txtNombreNuevaVenta.getText();
                pro = service.BuscarPro(nom);
                if (pro.getNombre() != null) {

                    txtDescripcionNuevaVenta.setText("" + pro.getCategoria());
                    txtPrecioNuevaVenta.setText("" + pro.getPrecio());
                    txtStockDisponibleNuevaVenta.setText("" + pro.getStock());
                    txtCantidadNuevaVenta.requestFocus();
                } else {
                    LimpiarVenta();
                    txtNombreNuevaVenta.requestFocus();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese el nombre del producto");
                txtNombreNuevaVenta.requestFocus();
            }
        }
    }//GEN-LAST:event_txtNombreNuevaVentaKeyPressed

    private void txtCantidadNuevaVentaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadNuevaVentaKeyPressed
//ingresar cantidad de un producto        
//metodo para comprobar que se presiona la tecla enter
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            //comrpobar que la cantidad no este vacia
            if (!"".equals(txtCantidadNuevaVenta.getText())) {
                String nom = txtNombreNuevaVenta.getText();
                String descripcion = txtDescripcionNuevaVenta.getText();
                int cant = Integer.parseInt(txtCantidadNuevaVenta.getText());
                double precio = Double.parseDouble(txtPrecioNuevaVenta.getText());
                double total = cant * precio;
                int stock = Integer.parseInt(txtStockDisponibleNuevaVenta.getText());
                if (stock >= cant) {
                    item = item + 1;
                    tmp = (DefaultTableModel) tableNuevaVenta.getModel();
                    for (int i = 0; i < tableNuevaVenta.getRowCount(); i++) {
                        if (tableNuevaVenta.getValueAt(0, 0).equals(txtNombreNuevaVenta.getText())) {
                            JOptionPane.showMessageDialog(null, "El producto ya esta registrado");
                            //para que el programa no continue
                            return;
                        }
                    }
                    ArrayList lista = new ArrayList();
                    lista.add(item);
                    lista.add(nom);
                    lista.add(descripcion);
                    lista.add(cant);
                    lista.add(precio);
                    lista.add(total);
                    Object[] o = new Object[5];
                    o[0] = lista.get(1);
                    o[1] = lista.get(2);
                    o[2] = lista.get(3);
                    o[3] = lista.get(4);
                    o[4] = lista.get(5);
                    tmp.addRow(o);
                    tableNuevaVenta.setModel(tmp);
                    TotalPagar();
                    LimpiarVenta();
                    txtNombreNuevaVenta.requestFocus();
                } else {
                    JOptionPane.showMessageDialog(null, "Stock no disponible");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese cantidad");
            }
        }
    }//GEN-LAST:event_txtCantidadNuevaVentaKeyPressed

    private void btnEliminarNuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarNuevaVentaActionPerformed

        limpiarTable();

    }//GEN-LAST:event_btnEliminarNuevaVentaActionPerformed

    private void txtDniNuevaVentaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDniNuevaVentaKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!"".equals(txtDniNuevaVenta.getText())) {
                String DNI = (txtDniNuevaVenta.getText());
                cl = cliente.BuscarCliente(DNI);

                if (cl.getNombre() != null) {
                    txtClienteNuevaVenta.setText("" + cl.getNombre());
                    txtApellidosNuevaVenta.setText("" + cl.getApellidos());
                    txtDireccionNuevaVenta.setText("" + cl.getDireccion());
                    txtTelefonoNuevaVenta.setText("" + cl.getTelefono());

                } else {
                    txtDniNuevaVenta.setText("");
                    JOptionPane.showMessageDialog(null, "El cliente no existe");
                }
            }
        }
    }//GEN-LAST:event_txtDniNuevaVentaKeyPressed

    private void txtDireccionNuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionNuevaVentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionNuevaVentaActionPerformed

    private void btnGuardarNuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarNuevaVentaActionPerformed
        saveVenta();
        saveDetalle();
        actualizarStock();
        LimpiarTableVenta();
        LimpiarClienteVenta();
    }//GEN-LAST:event_btnGuardarNuevaVentaActionPerformed

    private void btnNuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevaVentaActionPerformed

        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_btnNuevaVentaActionPerformed

    private void btnVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentasActionPerformed

        jTabbedPane1.setSelectedIndex(3);
        limpiarTable();
        getVenta();
    }//GEN-LAST:event_btnVentasActionPerformed

    private void btnHamburguesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHamburguesaActionPerformed
        CargarHamburguesa();
        TotalPagar();
    }//GEN-LAST:event_btnHamburguesaActionPerformed

    private void txtNombreNuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreNuevaVentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreNuevaVentaActionPerformed

    private void btnFileteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFileteActionPerformed
        CargarFilete();
        TotalPagar();
    }//GEN-LAST:event_btnFileteActionPerformed

    private void btnHamburguesaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHamburguesaMouseClicked


    }//GEN-LAST:event_btnHamburguesaMouseClicked

    private void btnCafeSoloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCafeSoloActionPerformed
        CargarCafeSolo();
        TotalPagar();
    }//GEN-LAST:event_btnCafeSoloActionPerformed

    private void lblFileteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblFileteMouseClicked

    }//GEN-LAST:event_lblFileteMouseClicked

    private void btnCafeLecheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCafeLecheActionPerformed
        CargarCafeLeche();
        TotalPagar();
    }//GEN-LAST:event_btnCafeLecheActionPerformed

    private void btnPatatasFritasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPatatasFritasActionPerformed
        CargarPatatasFritas();
        TotalPagar();
    }//GEN-LAST:event_btnPatatasFritasActionPerformed

    private void btnCroquetasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCroquetasActionPerformed
        CargarCroquetas();
        TotalPagar();
    }//GEN-LAST:event_btnCroquetasActionPerformed

    private void btnLubinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLubinaActionPerformed
        CargarLubina();
        TotalPagar();
    }//GEN-LAST:event_btnLubinaActionPerformed

    private void btnRodaballoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRodaballoActionPerformed
        CargarRodaballo();
        TotalPagar();
    }//GEN-LAST:event_btnRodaballoActionPerformed

    private void btnBesugoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBesugoActionPerformed
        CargarBesugo();
        TotalPagar();
    }//GEN-LAST:event_btnBesugoActionPerformed

    private void btnCocaColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCocaColaActionPerformed
        CargarCocaCola();
        TotalPagar();
    }//GEN-LAST:event_btnCocaColaActionPerformed

    private void btnFantaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFantaActionPerformed
        CargarFanta();
        TotalPagar();
    }//GEN-LAST:event_btnFantaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarCliente;
    private javax.swing.JButton btnActualizarProductos;
    private javax.swing.JButton btnActualizarVendedor;
    private javax.swing.JButton btnBesugo;
    private javax.swing.JButton btnCafeLeche;
    private javax.swing.JButton btnCafeSolo;
    private javax.swing.JButton btnClientes;
    private javax.swing.JButton btnCocaCola;
    private javax.swing.JButton btnCroquetas;
    private javax.swing.JButton btnEliminarCliente;
    private javax.swing.JButton btnEliminarNuevaVenta;
    private javax.swing.JButton btnEliminarProductos;
    private javax.swing.JButton btnEliminarVendedor;
    private javax.swing.JButton btnFanta;
    private javax.swing.JButton btnFilete;
    private javax.swing.JButton btnGuardarCliente;
    private javax.swing.JButton btnGuardarNuevaVenta;
    private javax.swing.JButton btnGuardarProductos;
    private javax.swing.JButton btnGuardarVendedor;
    private javax.swing.JButton btnHamburguesa;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnLimpiarCliente;
    private javax.swing.JButton btnLimpiarVendedor;
    private javax.swing.JButton btnLubina;
    private javax.swing.JButton btnNuevaVenta;
    private javax.swing.JButton btnPatatasFritas;
    private javax.swing.JButton btnProductos;
    private javax.swing.JButton btnRodaballo;
    private javax.swing.JButton btnVendedor;
    private javax.swing.JButton btnVentas;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JLabel lblApellidosCliente;
    private javax.swing.JLabel lblApellidosNuevaVenta;
    private javax.swing.JLabel lblApellidosVendedor;
    private javax.swing.JLabel lblBesugo;
    private javax.swing.JLabel lblCafeConLeche;
    private javax.swing.JLabel lblCafeSolo;
    private javax.swing.JLabel lblCantidadNuevaVenta;
    private javax.swing.JLabel lblCategoriaProducto;
    private javax.swing.JLabel lblClienteNuevaVenta;
    private javax.swing.JLabel lblCocaCola;
    private javax.swing.JLabel lblCroquetas;
    private javax.swing.JLabel lblDescripcionNuevaVenta;
    private javax.swing.JLabel lblDireccionCliente;
    private javax.swing.JLabel lblDireccionNuevaVenta;
    private javax.swing.JLabel lblDniCliente;
    private javax.swing.JLabel lblDniNuevaVenta;
    private javax.swing.JLabel lblDniVendedor;
    private javax.swing.JLabel lblFanta;
    private javax.swing.JLabel lblFilete;
    private javax.swing.JLabel lblHabitualCliente;
    private javax.swing.JLabel lblHamburguesa;
    private javax.swing.JLabel lblIconoRestaurante;
    private javax.swing.JLabel lblIdClientes;
    private javax.swing.JLabel lblIdProducto;
    private javax.swing.JLabel lblIdVendedor;
    private javax.swing.JLabel lblLubina;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblNombreCliente;
    private javax.swing.JLabel lblNombreNuevaVenta;
    private javax.swing.JLabel lblNombreVendedor;
    private javax.swing.JLabel lblPasswordVendedor;
    private javax.swing.JLabel lblPatatasFritas;
    private javax.swing.JLabel lblPrecioNuevaVenta;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblRodaballo;
    private javax.swing.JLabel lblStock;
    private javax.swing.JLabel lblStockDisponibleNuevaVenta;
    private javax.swing.JLabel lblTelefonoCliente;
    private javax.swing.JLabel lblTelefonoNuevaVenta;
    private javax.swing.JLabel lblTelefonoVendedor;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblTotalPagar;
    private javax.swing.JLabel lblTotalPagarNuevaVenta;
    private javax.swing.JLabel lblVendedorMenu;
    private javax.swing.JPanel lineaDivisoria;
    private javax.swing.JPanel panelIzq;
    private javax.swing.JTable tableClientes;
    private javax.swing.JTable tableNuevaVenta;
    private javax.swing.JTable tableProductos;
    private javax.swing.JTable tableVendedor;
    private javax.swing.JTable tableVentas;
    private javax.swing.JTextField txtApellidosCliente;
    private javax.swing.JTextField txtApellidosNuevaVenta;
    private javax.swing.JTextField txtApellidosVendedor;
    private javax.swing.JTextField txtCantidadNuevaVenta;
    private javax.swing.JTextField txtCategoriaProducto;
    private javax.swing.JTextField txtClienteNuevaVenta;
    private javax.swing.JTextField txtDescripcionNuevaVenta;
    private javax.swing.JTextField txtDireccionCliente;
    private javax.swing.JTextField txtDireccionNuevaVenta;
    private javax.swing.JTextField txtDniCliente;
    private javax.swing.JTextField txtDniNuevaVenta;
    private javax.swing.JTextField txtDniVendedor;
    private javax.swing.JTextField txtHabitualCliente;
    private javax.swing.JTextField txtIdCliente;
    private javax.swing.JTextField txtIdProducto;
    private javax.swing.JTextField txtIdVendedor;
    private javax.swing.JTextField txtIdVenta;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtNombreNuevaVenta;
    private javax.swing.JTextField txtNombreProducto;
    private javax.swing.JTextField txtNombreVendedor;
    private javax.swing.JTextField txtPasswordVendedor;
    private javax.swing.JTextField txtPrecioNuevaVenta;
    private javax.swing.JTextField txtPrecioProducto;
    private javax.swing.JTextField txtStockDisponibleNuevaVenta;
    private javax.swing.JTextField txtStockProducto;
    private javax.swing.JTextField txtTelefonoCliente;
    private javax.swing.JTextField txtTelefonoNuevaVenta;
    private javax.swing.JTextField txtTelefonoVendedor;
    // End of variables declaration//GEN-END:variables

}
